# LBP Extraction
 Extraction of Local Binary Pattern
