# Transfer-learning
 The transfer learning approaches for the endoscopic abnormalities detection.
